/* Test-only source inclusion; no alternate production entry point. */
#define main a249110_cli_main
#include "../src/a249110.c"
#undef main
int main(int argc,char **argv) {
    if(argc<2) return 1;
    if(!strcmp(argv[1],"chain")) {
        Scratch sc; scratch_init(&sc);
        for(int k=2;k<argc;++k) {
            uint64_t n; if(!dec64(argv[k],&n)) return 1;
            u128 v[9]={n}; bool fb=false;
            for(unsigned j=1;j<9;++j) {
                if(!derivative_wide(v[j-1],&v[j],&fb,&sc.wide)) return 1;
            }
            mpz_set_ui(sc.sum,0);
            for(unsigned j=0;j<9;++j) {
                char z[40]; fmt128(v[j],z); printf("%s ",z);
                mpz_set128(sc.z,v[j]); mpz_mul(sc.z,sc.z,sc.z); mpz_add(sc.sum,sc.sum,sc.z);
            }
            mpz_sqrt(sc.root,sc.sum); gmp_printf("%Zd ",sc.root);
            Hit hit;
            int result=v[1]>UINT64_MAX?-1:predicate(n,(uint64_t)v[1],&hit,&fb,&sc);
            printf("%d\n",result);
        }
        scratch_clear(&sc);
    } else if(!strcmp(argv[1],"factor")) {
        for(int k=2;k<argc;++k) {
            uint64_t n; u128 d; bool fb=false;
            if(!dec64(argv[k],&n)||!derivative64(n,&d,&fb)) return 1;
            char z[40]; fmt128(d,z); printf("%" PRIu64 " %s %d %d\n",n,z,prime64(n)?1:0,fb?1:0);
        }
    } else if(!strcmp(argv[1],"factorwide")) {
        WideScratch sc; wide_init(&sc);
        for(int k=2;k<argc;++k) {
            u128 n,d=0; bool fb=false;
            if(!dec128(argv[k],&n)) return 1;
            bool ok=derivative_wide(n,&d,&fb,&sc);
            char ns[40],ds[40]; fmt128(n,ns); fmt128(d,ds);
            printf("%s %s %d %d\n",ns,ds,ok?1:0,fb?1:0);
        }
        wide_clear(&sc);
    } else if(!strcmp(argv[1],"primewide")) {
        WideScratch sc; wide_init(&sc);
        for(int k=2;k<argc;++k) {
            u128 n; if(!dec128(argv[k],&n)) return 1;
            char ns[40]; fmt128(n,ns);
            printf("%s %d\n",ns,n>=WIDE_PRIME_LIMIT?-1:prime_wide(n,&sc)?1:0);
        }
        wide_clear(&sc);
    } else if(!strcmp(argv[1],"stopwide")) {
        WideScratch sc; wide_init(&sc); u128 out=0; bool fb=false;
        atomic_store(&stopped,1);
        bool ok=derivative_wide(MAX_D7,&out,&fb,&sc);
        atomic_store(&stopped,0); wide_clear(&sc);
        if(ok) return 1;
        puts("WIDE STOP INCOMPLETE");
    } else if(!strcmp(argv[1],"parallelwide")) {
        uint64_t workers;
        if(argc!=3||!dec64(argv[2],&workers)||workers<1||workers>16) return 1;
        unsigned failures=0;
#pragma omp parallel num_threads((int)workers) reduction(+:failures)
        {
            Scratch sc; scratch_init(&sc);
#pragma omp for schedule(dynamic,1)
            for(unsigned j=0;j<32;++j) {
                u128 p=((u128)1<<64)+13,n=3*p,out=0; bool fb=false;
                if(!derivative_wide(n,&out,&fb,&sc.wide)||out!=p+3) ++failures;
            }
            scratch_clear(&sc);
        }
        if(failures) return 1;
        puts("WIDE PARALLEL PASS");
    } else if(!strcmp(argv[1],"signalwide")) {
        u128 n,out=0; bool fb=false;
        if(argc!=3||!dec128(argv[2],&n)) return 1;
        struct sigaction sa={0};sa.sa_handler=on_signal;sigemptyset(&sa.sa_mask);
        if(sigaction(SIGTERM,&sa,NULL)) return 1;
        WideScratch sc;wide_init(&sc);
        puts("WIDE_WORK_STARTED");if(fflush(stdout)) return 1;
        bool ok=derivative_wide(n,&out,&fb,&sc);wide_clear(&sc);
        if(ok||!stop_requested()) return 1;
        puts("WIDE_SIGNAL_INCOMPLETE");return 2;
    } else if(!strcmp(argv[1],"width")) {
        Scratch sc; scratch_init(&sc); mpz_set_ui(sc.sum,0);
        for(unsigned j=0;j<9;++j) {
            u128 v=chain_bound(j);
            mpz_set128(sc.z,v); u128 back=0;
            if(!mpz_get128_checked(sc.z,&back)||back!=v) return 1;
            mpz_mul(sc.z,sc.z,sc.z); mpz_add(sc.sum,sc.sum,sc.z);
        }
        mpz_sqrt(sc.root,sc.sum); gmp_printf("%Zd %Zd\n",sc.sum,sc.root);
        Hit h; for(unsigned j=0;j<7;++j) h.x[j]=bounds[j]; h.x7=MAX_D7; h.x8=MAX_D8; h.root=MAX_ROOT;
        char row[256]; if(hit_text(&h,row)!=HIT_ROW_MAX) return 1;
        row[HIT_ROW_MAX-1]=0; Hit back; parse_hit(row,&back); if(!equal_hit(&h,&back)) return 1;
        for(unsigned j=0;j<128;++j) {
            u128 v=(u128)1<<j,out=0; mpz_set128(sc.z,v);
            if(!mpz_get128_checked(sc.z,&out)||v!=out) return 1;
            mpz_mul(sc.z,sc.z,sc.z); if(!mpz_perfect_square_p(sc.z)) return 1;
            mpz_add_ui(sc.z,sc.z,1); if(j&&mpz_perfect_square_p(sc.z)) return 1;
        }
        scratch_clear(&sc);
    } else if(!strcmp(argv[1],"guards")) {
        Segment s={.low=2,.high=4,.frontier=1,.nhit=(size_t)HIT_GUARD};
        Hit h={0}; if(push_hit(&s,h)) return 1;
        s.nhit=0; Config c={.start=2,.end=4,.segments=1,.threads=1};
        Primes pr=make_primes(4); uint64_t fb=0;
        if(block_scan(&c,&pr,&s,2,4,HIT_GUARD,&fb)||s.frontier!=1||s.nhit) return 1;
        free(pr.v); free_seg(&s);
        live_enabled=true; live_target=4; live_segment=0;live_segments=1;
        live_frontier=1;live_units=0;live_fallbacks=0;live_begin=ns_now();
        atomic_store(&next_note,0);active_input=4;heartbeat(4);
        puts("GUARDS PASS");
    } else if(!strcmp(argv[1],"partition")) {
        const uint64_t ends[]={2,3,BLOCK+1,BLOCK+2,1072281223,2000000000,4000000000,CAP-1,CAP};
        for(size_t k=0;k<sizeof ends/sizeof ends[0];++k) {
            Config c={.start=2,.end=ends[k],.threads=16};
            for(c.segments=1;c.segments<=MAX_SEGMENTS&&c.segments<=blocks(&c);++c.segments) {
                uint64_t prev=1,total=0,min=UINT64_MAX,max=0;
                for(uint64_t j=0;j<c.segments;++j) {
                    uint64_t lo,hi; seg_bounds(&c,j,&lo,&hi);
                    if(lo!=prev+1||hi<lo) return 1;
                    Segment s={.low=lo,.high=hi,.frontier=hi}; uint64_t b=completed_blocks(&s);
                    total+=b; if(b<min) min=b; if(b>max) max=b; prev=hi;
                }
                if(prev!=c.end||total!=blocks(&c)||max-min>1) return 1;
            }
        }
        puts("PARTITION PASS");
    } else return 1;
    return ferror(stdout)?1:0;
}
