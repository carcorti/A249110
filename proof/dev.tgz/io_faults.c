#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
/* Disposable deterministic I/O fault control, loaded only in isolated tests. */
static unsigned calls;
static int fail(const char *op) {
    const char *want=getenv("A249110_FAULT"),*at=getenv("A249110_AT");
    return want&&at&&!strcmp(want,op)&&++calls==(unsigned)strtoul(at,NULL,10);
}
int fsync(int fd) {
    static int (*real)(int);
    if(!real) *(void **)(&real)=dlsym(RTLD_NEXT,"fsync");
    if(fail("fsync")) {errno=EIO;return -1;} return real(fd);
}
int rename(const char *a,const char *b) {
    static int (*real)(const char *,const char *);
    if(!real) *(void **)(&real)=dlsym(RTLD_NEXT,"rename");
    if(fail("rename")) {errno=EIO;return -1;} return real(a,b);
}
int link(const char *a,const char *b) {
    static int (*real)(const char *,const char *);
    if(!real) *(void **)(&real)=dlsym(RTLD_NEXT,"link");
    if(fail("link")) {errno=EIO;return -1;} return real(a,b);
}
#include <stdio.h>
int fflush(FILE *f) {
    static int (*real)(FILE *);
    if(!real) *(void **)(&real)=dlsym(RTLD_NEXT,"fflush");
    if(fail("fflush")) {errno=ENOSPC;return EOF;} return real(f);
}
