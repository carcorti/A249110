#!/usr/bin/env python3
"""Supplemental release-binary coverage of the 5E10 cap and real wide x7 paths."""
from pathlib import Path
import json,tempfile,subprocess,argparse,math
from check import ROOT,command,require,LOG,build_helper,run
from wide import chain

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--exe',type=Path,default=ROOT/'src/a249110');ap.add_argument('--log',type=Path);a=ap.parse_args()
 expected=[chain(n) for n in [2**35,5*2**33,*range(49999999992,50000000001)]]
 try:
  with tempfile.TemporaryDirectory(prefix='a249110-delta-') as td:
    tmp=Path(td);helper=build_helper(tmp)
    r=command([helper,'chain',*[row[0] for row in expected]])
    actual=[list(map(int,l.split())) for l in r.stdout.splitlines()];require(actual==expected,'new-cap chain mismatch')
    require(all(row[7]>2**64-1 for row in expected[:2]),'real wide-path fixture not wide')
    for row in expected[:2]:
        d=tmp/str(row[0]);hh=run(a.exe.resolve(),d,row[0],row[0],workers=16)
        require(hh==([row[:-1]] if row[-1] else []),'release real wide-path classification')
        command(['python3','-B',ROOT/'validation/verify.py',d,'--source-root',a.exe.resolve().parent.parent])
    hh=run(a.exe.resolve(),tmp/'cap',49999999992,50000000000,workers=16)
    require(hh==[row[:-1] for row in expected[2:] if row[-1]],'new-cap output mismatch')
    command([a.exe.resolve(),'init',tmp/'bad',50000000001,50000000001,1,1],expect=1)
    # New proof/constants do not alter immutable expected pre-code cases.
    command(['python3','-B',ROOT/'validation/verify.py',tmp/'cap','--source-root',a.exe.resolve().parent.parent])
    LOG.append({'status':'PASS','expected':expected,'production_distinct':11,'real_wide_x7_inputs':2,'independent_prime_certification':'recursive Lucas certificates via wide.py','no_rank':True})
 finally:
  if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
 print('CAPACITY DELTA PASS')
if __name__=='__main__':main()
