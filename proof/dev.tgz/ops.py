#!/usr/bin/env python3
"""Private-root persistence, grammar, locking and fault matrix for A249110."""
from pathlib import Path
import argparse, fcntl, hashlib, json, os, shutil, signal, subprocess, tempfile, time
from check import ROOT, LOG, command, require, run, hits

def snapshot(d):return {p.name:p.read_bytes() for p in d.iterdir() if p.is_file()}
def rehash_state(p):
    b=p.read_bytes().split(b'state_sha\t')[0];p.write_bytes(b+b'state_sha\t'+hashlib.sha256(b).hexdigest().encode()+b'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--exe',type=Path,default=ROOT/'src/a249110');ap.add_argument('--log',type=Path);ap.add_argument('--signals',action='store_true');a=ap.parse_args();exe=a.exe.resolve()
    try:
      with tempfile.TemporaryDirectory(prefix='a249110-ops-') as td:
        tmp=Path(td);base=tmp/'base';expected=run(exe,base,2,4096,workers=2)
        initial=tmp/'initial';command([exe,'init',initial,2,4096,1,2])
        def clone(name,src=base):
            d=tmp/name;shutil.copytree(src,d);return d
        def refuse(d,verb='next'):
            old=snapshot(d);command([exe,verb,d],expect=1);require(snapshot(d)==old,'refusal changed bytes')
        for name in ['man.tsv','hits.tsv','both']:
            for src,label in [(base,'done'),(initial,'init')]:
                d=clone('missing-'+name+'-'+label,src)
                for p in (['man.tsv','hits.tsv'] if name=='both' else [name]):(d/p).unlink()
                old=snapshot(d);command([exe,'status',d],expect=2);require(snapshot(d)==old,'status mutated')
                inode=(d/'run.cfg').stat().st_ino;command([exe,'next',d]);command([exe,'verify',d])
                require(hits(d)==expected and (d/'run.cfg').stat().st_ino==inode,'missing-derived recovery')
        d=clone('unsealed');(d/'s000.sha').unlink()
        for p in ['man.tsv','hits.tsv']:(d/p).write_bytes((initial/p).read_bytes())
        # Different config identity in initial: replace only the header identity.
        cfg=hashlib.sha256((d/'run.cfg').read_bytes()).hexdigest()
        for p in ['man.tsv','hits.tsv']:
            rows=(d/p).read_text().splitlines();rows[0]=rows[0].split('=')[0]+'='+cfg;(d/p).write_text('\n'.join(rows)+'\n')
        oldstate=(d/'s000.tsv').read_bytes();r=command([exe,'next',d]);require('no_enumeration' in r.stderr and (d/'s000.tsv').read_bytes()==oldstate,'complete-unsealed rescan')
        for file in ['run.cfg','s000.tsv','s000.sha','man.tsv','hits.tsv']:
            for label,mut in [('nul',lambda b:b[:4]+b'\0'+b[5:]),('cr',lambda b:b.replace(b'\n',b'\r\n',1)),('cut',lambda b:b[:-1]),('extra',lambda b:b+b'extra\n'),('huge',lambda b:b'x'*256+b'\n'+b)]:
                d=clone(file+'-'+label);p=d/file;p.write_bytes(mut(p.read_bytes()));refuse(d)
        for key,value in [('id',b'1'),('low',b'3'),('high',b'4095'),('frontier',b'4095'),('blocks',b'2'),('hits',b'1000001'),('elapsed_ns',b'01'),('fallbacks',b'4096')]:
            d=clone('field-'+key);p=d/'s000.tsv';lines=p.read_bytes().splitlines(keepends=True)
            p.write_bytes(b''.join(key.encode()+b'\t'+value+b'\n' if x.startswith(key.encode()+b'\t') else x for x in lines));rehash_state(p);refuse(d)
        for tag,mut in [('false-positive',lambda b:b.replace(b'4\t4\t4\t4\t4\t4\t4\t4\t4\t12',b'4\t4\t4\t4\t4\t4\t4\t4\t4\t13')),('extra-column',lambda b:b.replace(b'\t12\n',b'\t12\t0\n')),('order',lambda b:b.replace(b'hit\t27\t',b'hit\t3\t'))]:
            d=clone(tag);p=d/'s000.tsv';p.write_bytes(mut(p.read_bytes()));rehash_state(p);(d/'s000.sha').unlink();refuse(d)
        for file in ['s000.tsv','run.cfg']:
            d=clone('authority-'+file);(d/file).unlink();(d/'hits.tmp').write_text('stale\n');refuse(d)
        d=clone('bad-survivor');(d/'hits.tsv').unlink();(d/'man.tsv').write_text('foreign\n');(d/'hits.tmp').write_text('stale\n');refuse(d)
        d=clone('partial-hits');p=d/'hits.tsv';p.write_bytes(b'\n'.join(p.read_bytes().splitlines()[:3])+b'\n');refuse(d)
        d=clone('stale');(d/'hits.tmp').write_text('untrusted partial temporary\n');command([exe,'next',d]);require(not (d/'hits.tmp').exists(),'recognized temp not cleaned')
        d=clone('foreign');(d/'unknown').write_text('x');refuse(d)
        rootlink=tmp/'rootlink';rootlink.symlink_to(base,target_is_directory=True)
        for suffix in ['', '/']:
            command([exe,'status',str(rootlink)+suffix],expect=1)
        d=clone('symlink');(d/'hits.tsv').unlink();(d/'hits.tsv').symlink_to(base/'hits.tsv');refuse(d)
        d=clone('fifo');(d/'hits.tsv').unlink();os.mkfifo(d/'hits.tsv');refuse(d)
        # Missing future state, or future authority advanced before predecessor.
        d=tmp/'future';command([exe,'init',d,2,524290,3,2]);(d/'s002.tsv').unlink();refuse(d)
        d=clone('locks')
        with (d/'run.cfg').open('rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB);command([exe,'status',d]);command([exe,'next',d],expect=1)
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);command([exe,'status',d],expect=1)
        command([exe,'next',d]);require(hits(d)==expected,'done mutation')
        lib=tmp/'fault.so';command(['gcc','-shared','-fPIC',ROOT/'validation/io_faults.c','-ldl','-o',lib])
        for op,positions in [('fsync',range(1,13)),('link',range(1,6)),('rename',range(1,4))]:
            for at in positions:
                d=tmp/f'f-{op}-{at}';env={**os.environ,'LD_PRELOAD':str(lib),'A249110_FAULT':op,'A249110_AT':str(at)}
                r=command([exe,'init',d,2,4096,1,2],expect=(0,1),env=env)
                if r.returncode:
                    if (d/'run.cfg').exists():command([exe,'next',d]);command([exe,'verify',d]);require(hits(d)==expected,'post-init fault recovery')
                    else:command([exe,'next',d],expect=1)
                else:
                    r=command([exe,'next',d],expect=(0,1),env=env)
                    if r.returncode:command([exe,'next',d])
                    command([exe,'verify',d]);require(hits(d)==expected,'commit fault recovery')
        if a.signals:
            for wanted in [0,1,2]:
                d=tmp/f'sig{wanted}';command([exe,'init',d,2,823543,1,1]);start=time.monotonic()
                p=subprocess.Popen([str(exe),'next',str(d)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                first=p.stderr.readline();require(first.startswith("START "),"missing live start")
                while p.poll() is None:
                    text=(d/'s000.tsv').read_text();front=int(next(x.split('\t')[1] for x in text.splitlines() if x.startswith('frontier\t')))
                    if front>=1+wanted*262144: p.send_signal(signal.SIGTERM);break
                    require(time.monotonic()-start<30,'signal fixture deadline');time.sleep(.001)
                out,err=p.communicate(timeout=10);LOG.append({'test':'signal','wanted_blocks':wanted,'rc':p.returncode,'stdout':out,'stderr':first+err})
                require(p.returncode==2,'signal fixture missed partial state')
                command([exe,'next',d]);command([exe,'verify',d]);require([r[0] for r in hits(d)]==[4,27,3125,398747,823543],'signal resume census')
        LOG.append({'status':'PASS','tests':'persistence, adversarial grammar, locks, deterministic I/O faults','signals':a.signals})
    finally:
        if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
    print(json.dumps(LOG[-1]))
if __name__=='__main__':main()
