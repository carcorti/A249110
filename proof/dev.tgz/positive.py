#!/usr/bin/env python3
"""Synthetic maximum-width positive-output transport, followed by refusal.

The injected chain is deliberately NOT a mathematical witness. Only test code
can bypass the predicate. The real producer/verifier must reject it unchanged.
This exercises widest durable state/aggregate rows without inventing a term.
"""
from pathlib import Path
import argparse,json,os,tempfile
from check import ROOT,LOG,command,require,digest

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--log',type=Path);a=ap.parse_args()
    body='''#define main producer_main
#include "SOURCE"
#undef main
int main(int argc,char **argv) {
    if(argc!=2) return 1;
    Config c={0};config_load(argv[1],&c);
    Segment s={.id=0,.low=CAP,.high=CAP,.frontier=CAP,.elapsed_ns=1};
    Hit h;for(unsigned j=0;j<7;++j)h.x[j]=bounds[j];
    h.x7=MAX_D7;h.x8=MAX_D8;h.root=MAX_ROOT;
    if(!push_hit(&s,h)) return 1;
    write_seg(argv[1],&c,&s,true);seal_segment(argv[1],&s);
    (void)aggregates(argv[1],&c,1,true);
    free_seg(&s);free_cfg(&c);return 0;
}
'''.replace('SOURCE',str(ROOT/'src/a249110.c'))
    try:
      with tempfile.TemporaryDirectory(prefix='a249110-positive-') as td:
        tmp=Path(td);source=tmp/'positive.c';source.write_text(body);helper=tmp/'positive'
        command(['gcc','-std=c17','-O1','-g','-fopenmp','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie',
                 '-DA249110_SOURCE_SHA="'+digest(ROOT/'src/a249110.c')+'"',
                 '-DA249110_MAKE_SHA="'+digest(ROOT/'src/Makefile')+'"',source,'-lgmp','-lcrypto','-o',helper])
        d=tmp/'run';exe=ROOT/'src/a249110';command([exe,'init',d,50000000000,50000000000,1,1])
        env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
        command([helper,d],env=env)
        state=(d/'s000.tsv').read_bytes();hit=next(x for x in state.splitlines(keepends=True) if x.startswith(b'hit\t'))
        require(len(hit)==184 and hit[4:]==(d/'hits.tsv').read_bytes().splitlines(keepends=True)[2],'widest durable output mismatch')
        before={p.name:p.read_bytes() for p in d.iterdir()}
        command([exe,'verify',d],expect=1)
        require(before=={p.name:p.read_bytes() for p in d.iterdir()},'mathematical refusal mutated injected state')
        command(['python3','-B',ROOT/'validation/verify.py',d],expect=1)
        LOG.append({'status':'PASS','test_source':body,'synthetic_not_a_witness':True,'state_hit_bytes':len(hit),
                    'state':state.decode(),'aggregate':(d/'hits.tsv').read_text(),
                    'sanitizers':'ASan/UBSan; LSan disabled because this sandbox runs under ptrace (failed attempt retained in posbad.json); Valgrind separately covers the real wide release path','native_and_independent_refusal':True})
    finally:
      if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
    print('MAXIMUM-WIDTH DURABLE TRANSPORT AND FALSE-WITNESS REFUSAL PASS')

if __name__=='__main__':main()
