#!/usr/bin/env python3
"""A249110 bounded independent arithmetic and native checks. No official run.

Direct trial division + Python isqrt is independent of C sieve/MR/rho/GMP.
Native inclusion fixtures test helper boundaries and are correlated C evidence.
All producer invocations write only private TemporaryDirectory roots.
"""
from pathlib import Path
import argparse, hashlib, json, math, os, shutil, subprocess, tempfile, time, shlex
ROOT=Path(__file__).resolve().parents[1]
CAP=50000000000
LOG=[]
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def command(args,expect=0,timeout=40,env=None):
    t=time.monotonic(); r=subprocess.run(list(map(str,args)),capture_output=True,text=True,timeout=timeout,env=env)
    LOG.append({'argv':list(map(str,args)),'rc':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':time.monotonic()-t})
    require(r.returncode in (expect if isinstance(expect,tuple) else (expect,)),str(LOG[-1]))
    return r

def derivative(n):
    if n<2:return 0
    original=n;s=0;p=2
    while p<=n//p:
        e=0
        while n%p==0: n//=p;e+=1
        s+=e*(original//p);p=3 if p==2 else p+2
    if n>1:s+=original//n
    return s

def arithmetic(n):
    xs=[n]
    for _ in range(8):xs.append(derivative(xs[-1]))
    q=sum(x*x for x in xs);r=math.isqrt(q)
    return xs,r,n>=2 and r*r==q

def hits(d):
    rows=(d/'hits.tsv').read_text().splitlines()
    return [list(map(int,x.split('\t'))) for x in rows[2:]]

def run(exe,d,lo,hi,segments=1,workers=1):
    command([exe,'init',d,lo,hi,segments,workers])
    for _ in range(segments):command([exe,'next',d])
    command([exe,'verify',d]);return hits(d)

def build_helper(folder,cc='gcc',extra=()):
    # Adjacent include path is resolved in source, no generated production file.
    out=folder/'helper'
    args=[os.getenv("A249110_TEST_CC",cc),'-std=c17','-O2','-g','-fopenmp',*shlex.split(os.getenv("A249110_TEST_FLAGS","")),*extra,
      '-DA249110_SOURCE_SHA="'+digest(ROOT/'src/a249110.c')+'"',
      '-DA249110_MAKE_SHA="'+digest(ROOT/'src/Makefile')+'"',ROOT/'validation/native.c','-lgmp','-lcrypto','-o',out]
    command(args);return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--exe',type=Path,default=ROOT/'src/a249110');ap.add_argument('--log',type=Path);ap.add_argument('--quick',action='store_true');a=ap.parse_args()
    exe=a.exe.resolve()
    cases=json.loads((ROOT/'outputs/precode/cases.json').read_text())['rows']
    selected=json.loads((ROOT/'outputs/precode/oracle.json').read_text())['selected_results']
    try:
      with tempfile.TemporaryDirectory(prefix='a249110-check-') as td:
        tmp=Path(td); helper=build_helper(tmp)
        for row in cases:
            xs,r,member=arithmetic(row['n'])
            require(xs==row['chain'] and r==row['R_floor'] and member==row['member'],'independent expected data disagreement')
        LOG.append({'test':'independent-small','distinct':len(cases),'transitions':len(cases)*8,'positives':[c['n'] for c in cases if c['member']]})
        inputs={r['n']:r for r in cases+selected}
        output=command([helper,'chain',*inputs]).stdout.splitlines()
        require(len(output)==len(inputs),'helper row count')
        for actual,row in zip(output,inputs.values()):
            v=list(map(int,actual.split()));result=-1 if not 2<=row['n']<=CAP else int(row['member'])
            require(v==row['chain']+[row['R_floor'],result],f'chain mismatch {row["n"]}: {v}')
        command([helper,'partition']);g=command([helper,'guards']);require('blocks=0 saved_fallback_inputs=0 active_input=4 factor_operand=4' in g.stderr,'heartbeat regression');r=command([helper,'width'])
        require(r.stdout.strip()=='20949186494680010958899369285145516085084160 4577028129111728646739','wide GMP bound mismatch')
        factors=[0,1,2,4,73,193,407521,299210837,3215031751,341550071728321,3825123056546413051,18446744073709551557,2**63,2**64-1,1000003*1000033]
        import sympy
        out=command([helper,'factor',*factors]).stdout.splitlines()
        for n,line in zip(factors,out):
            f=sympy.factorint(n) if n>1 else {};expected=sum(int(e)*(n//int(p)) for p,e in f.items())
            vs=list(map(int,line.split()));require(vs[:3]==[n,expected,int(sympy.isprime(n))],f'factor mismatch {n}')
        forced=tmp/'forced';forced.mkdir();fh=build_helper(forced,extra=['-DA249110_FORCE_FALLBACK'])
        r=command([fh,'factor',101*103,1009*1013]);require(all(x.split()[-1]=='1' for x in r.stdout.splitlines()),'fallback not exercised')
        expect=[r['chain']+[r['R_floor']] for r in cases if r['member']]
        for w in ([1,2,4,8,16] if not a.quick else [2]):
            require(run(exe,tmp/f'w{w}',2,4096,workers=w)==expect,'released small-domain mismatch')
        for n in [4,27,3125,398747,823543,1072281223,49]:
            row=next((r for r in selected+cases if r['n']==n),None)
            xs,rt,mem=arithmetic(n)
            require(run(exe,tmp/f'n{n}',n,n,workers=2)==([xs+[rt]] if mem else []),'isolated native mismatch')
        windows=json.loads((ROOT/'outputs/precode/oracle.json').read_text())['selected_windows']
        for j,win in enumerate(windows):
            want=[r['chain']+[r['R_floor']] for r in selected if win['low']<=r['n']<=win['high'] and r['member']]
            require(run(exe,tmp/f'e{j}',win['low'],win['high'],workers=4)==want,'selected native window mismatch')
        for bad in ['0','1',str(CAP+1),'285311670611','-2','+2',' 2','2x','02','18446744073709551616','2\r']:
            command([exe,'init',tmp/'bad',bad,bad,1,1],expect=1)
        for fields in [(2,1,1,1),(2,3,2,1),(2,3,0,1),(2,3,1,0),(2,3,1,17),(2,CAP,257,1)]:
            command([exe,'init',tmp/'bad',*fields],expect=1)
        for args in [[],['unknown'],['next'],['status','x','x'],['init']]:command([exe,*args],expect=1)
        if not a.quick:
            outputs=[]
            for s,w in [(1,1),(2,4),(3,16)]:outputs.append(run(exe,tmp/f'p{s}',2,524290,s,w))
            require(outputs[0]==outputs[1]==outputs[2],'partition release mismatch')
        LOG.append({'status':'PASS','kind':'bounded correctness, not campaign','small_distinct':4095,'helper_distinct':len(inputs),'selected_overlap':True})
    finally:
      if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
    print(json.dumps(LOG[-1]))
if __name__=='__main__':main()
