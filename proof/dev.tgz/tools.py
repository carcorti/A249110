#!/usr/bin/env python3
"""Isolated toolchain/sanitizer qualification. Never rebuilds canonical bytes."""
from pathlib import Path
import os,subprocess,json,tempfile,shutil,hashlib,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/rev5'
def main():
 logs={};bind=['-DA249110_SOURCE_SHA="'+hashlib.sha256((ROOT/'src/a249110.c').read_bytes()).hexdigest()+'"','-DA249110_MAKE_SHA="'+hashlib.sha256((ROOT/'src/Makefile').read_bytes()).hexdigest()+'"']
 def run(name,args,env=None,timeout=50):
    t=time.monotonic()
    try:
        r=subprocess.run(list(map(str,args)),text=True,capture_output=True,env=env,timeout=timeout);d={'argv':list(map(str,args)),'rc':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':time.monotonic()-t}
    except subprocess.TimeoutExpired as e:d={'argv':list(map(str,args)),'timeout':True,'stdout':str(e.stdout),'stderr':str(e.stderr),'seconds':time.monotonic()-t}
    logs[name]=d;(OUT/'tools.json').write_text(json.dumps(logs,indent=2)+'\n');print(name,d.get('rc','TIMEOUT'),flush=True);return d
 with tempfile.TemporaryDirectory(prefix='a249110-tools-') as td:
    tmp=Path(td);src=tmp/'src';src.mkdir();(tmp/'data').mkdir()
    for name in ['a249110.c','Makefile']:shutil.copyfile(ROOT/'src'/name,src/name)
    shutil.copyfile(ROOT/'data/b249110.txt',tmp/'data/b249110.txt')
    for kind,cc,flags in [('asan','gcc',['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']),('clang','clang-18',[])]:
        d=run(kind+'-build',[cc,'-std=c17','-O1','-g','-fopenmp',*flags,*bind,src/'a249110.c','-lgmp','-lcrypto','-o',src/'a249110'])
        if d.get('rc')==0:
            logs[kind+'-identity']={'source':hashlib.sha256((src/'a249110.c').read_bytes()).hexdigest(),'makefile':hashlib.sha256((src/'Makefile').read_bytes()).hexdigest(),'binary':hashlib.sha256((src/'a249110').read_bytes()).hexdigest()}
            env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','A249110_TEST_FLAGS':' '.join(flags),'A249110_TEST_CC':cc}
            run(kind+'-matrix',['python3','-B',ROOT/'validation/check.py','--exe',src/'a249110','--log',OUT/(kind+'raw.json')],env=env,timeout=60)
            run(kind+'-wide',['python3','-B',ROOT/'validation/wide.py','--exe',src/'a249110','--log',OUT/(kind+'wide.json')],env=env,timeout=60)
            if kind=='asan':run('asan-ops',['python3','-B',ROOT/'validation/ops.py','--exe',src/'a249110','--log',OUT/'asanops.json'],env=env,timeout=60)
    archer=Path('/usr/lib/llvm-18/lib/libarcher.so')
    env={**os.environ,'OMP_TOOL':'enabled','OMP_TOOL_LIBRARIES':str(archer),'TSAN_OPTIONS':'ignore_noninstrumented_modules=1:halt_on_error=1:exitcode=66'}
    env['A249110_TEST_FLAGS']='-fsanitize=thread -fno-omit-frame-pointer';env['A249110_TEST_CC']='clang-18'
    logs['tsan-environment']={'compiler':'clang-18','runtime':'libomp','env':{k:env[k] for k in ['OMP_TOOL','OMP_TOOL_LIBRARIES','TSAN_OPTIONS']},'archer_sha256':hashlib.sha256(archer.read_bytes()).hexdigest() if archer.exists() else None}
    flags=['-std=c17','-O1','-g','-fopenmp','-fsanitize=thread','-fno-omit-frame-pointer']
    run('tsan-build',['clang-18',*flags,ROOT/'validation/tsan_controls.c','-o',tmp/'control'])
    startup=run('tsan-startup',[tmp/'control','startup'],env)
    sync=run('tsan-sync',[tmp/'control','sync'],env)
    race=run('tsan-race',[tmp/'control','race'],env)
    qualified=startup.get('rc')==0 and sync.get('rc')==0 and race.get('rc')==66 and 'data race' in race.get('stderr','')
    logs['tsan-qualified']={'value':qualified,'classification':'PASS_CONTROLS' if qualified else 'ENVIRONMENTAL_OR_CONTROL_FAILURE_NOT_CANDIDATE_PASS'}
    # A candidate attempt is recorded even if controls cannot qualify the path.
    run('tsan-candidate-build',['clang-18',*flags,*bind,src/'a249110.c','-lgmp','-lcrypto','-o',src/'a249110'])
    run('tsan-candidate',['python3','-B',ROOT/'validation/check.py','--exe',src/'a249110','--log',OUT/'tsanraw.json'],env,timeout=60)
    run('tsan-wide',['python3','-B',ROOT/'validation/wide.py','--exe',src/'a249110','--log',OUT/'tsanwide.json'],env,timeout=60)
    run('tsan-ops',['python3','-B',ROOT/'validation/ops.py','--exe',src/'a249110','--log',OUT/'tsanops.json'],env,timeout=60)
    (OUT/'tools.json').write_text(json.dumps(logs,indent=2)+'\n')
if __name__=='__main__':main()
