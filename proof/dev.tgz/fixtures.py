#!/usr/bin/env python3
"""Reconstruct the exact retained small expected-data file in a NEW directory.
Independent complete trial division + Python integers/isqrt; no producer call.
Used only for review transport/reproduction, not a second production lineage.
"""
from pathlib import Path
import argparse,hashlib,json,math
EXPECTED='a9c354bbb892a415864df89412d9413cc5179094ba5dfe14546298d8818ecd50'
def derivative(n):
    if n<2:return 0
    z=n;s=0;p=2
    while p<=z//p:
        e=0
        while z%p==0:z//=p;e+=1
        s+=e*(n//p);p=3 if p==2 else p+2
    if z>1:s+=n//z
    return s
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--write',type=Path,required=True);a=ap.parse_args()
    rows=[]
    for n in range(2,4097):
        chain=[n]
        for _ in range(8):chain.append(derivative(chain[-1]))
        q=sum(x*x for x in chain);r=math.isqrt(q)
        rows.append({'n':n,'chain':chain,'Q8':q,'R_floor':r,'member':r*r==q,'production_domain':True})
    raw=(json.dumps({'scope':'Complete finite expected comparisons for future canonical C; not a new implementation','interval':[2,4096],'rows':rows},indent=2)+'\n').encode()
    h=hashlib.sha256(raw).hexdigest()
    if h!=EXPECTED:raise SystemExit('Expected-data regeneration hash mismatch')
    a.write.mkdir(parents=False,exist_ok=False)
    (a.write/'cases.json').write_bytes(raw)
    print(json.dumps({'status':'PASS','sha256':h,'distinct_inputs':len(rows),'transitions':8*len(rows),'positives':[r['n'] for r in rows if r['member']]}))
if __name__=='__main__':main()
