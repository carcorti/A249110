#!/usr/bin/env python3
"""One-shot authorized calibration, exactly the frozen eight-arm protocol.
Refuses an existing receipt. No automatic retries. 300 seconds includes setup,
all invocations, checks and archive closure. Raw state is retained in calib.tgz.
"""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile,time,tarfile
from verify import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/rev5';EXE=ROOT/'src/a249110'
def main():
    receipt=OUT/'calib.json'
    if receipt.exists():raise SystemExit('Receipt exists: no retry is authorized by this driver')
    started=time.monotonic();batch_deadline=started+300
    r={'protocol_sha256':hashlib.sha256((OUT/'calplan.json').read_bytes()).hexdigest(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'candidate':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/a249110.c',ROOT/'src/Makefile',EXE]},'cap_seconds':300,'arms':[],'rank_assigned':False,'official_campaign':False}
    receipt.write_text(json.dumps(r,indent=2)+'\n')
    spec=json.loads((OUT/'calplan.json').read_text())
    with tempfile.TemporaryDirectory(prefix='a249110-cal-') as td:
      tmp=Path(td);r['private_raw_root']=str(tmp);receipt.write_text(json.dumps(r,indent=2)+'\n')
      for window in spec['windows']:
        ws=time.monotonic();window_deadline=min(ws+60,batch_deadline)
        for workers in window['workers']:
          armstart=time.monotonic();deadline=min(armstart+25,window_deadline,batch_deadline)
          if deadline-armstart<4:
            r['arms'].append({'window':window['id'],'workers':workers,'status':'NOT_STARTED_BUDGET'});continue
          tag=window['id']+str(workers);root=tmp/tag
          arm={'window':window['id'],'workers':workers,'low':window['low'],'high':window['high'],'planned_inputs':window['inputs'],'logs':[]}
          def call(args,timeout):
            t=time.monotonic();p=subprocess.run(list(map(str,args)),capture_output=True,text=True,timeout=max(.1,timeout))
            arm['logs'].append({'argv':list(map(str,args)),'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-t});return p
          p=call([EXE,'init',root,window['low'],window['high'],1,workers],deadline-time.monotonic()-2)
          arm['setup_seconds']=time.monotonic()-armstart
          if p.returncode:arm['status']='INIT_FAILED'
          else:
            runlimit=max(.1,deadline-time.monotonic()-2)
            timing=tmp/(tag+'.txt')
            t=time.monotonic();p=call(['/usr/bin/time','-v','-o',timing,'timeout','--signal=TERM','--kill-after=1',str(runlimit),EXE,'next',root],runlimit+1.5)
            arm['next_wall_seconds']=time.monotonic()-t
            arm['time_v']=timing.read_text() if timing.exists() else None
            for line in (arm['time_v'] or '').splitlines():
                if 'Maximum resident set size (kbytes)' in line:arm['max_rss_bytes']=int(line.split(':')[-1])*1024
                if 'User time (seconds)' in line:arm['user_cpu_seconds']=float(line.split(':')[-1])
                if 'System time (seconds)' in line:arm['system_cpu_seconds']=float(line.split(':')[-1])
            arm['status']='COMPLETE' if p.returncode==0 else 'INCOMPLETE'
            v=call([EXE,'verify',root],deadline-time.monotonic())
            arm['native_verify_rc']=v.returncode
            t=time.monotonic();arm['independent_record_audit']=audit(root,ROOT);arm['independent_audit_seconds']=time.monotonic()-t
            state=(root/'s000.tsv').read_text();fields={x.split('\t')[0]:x.split('\t')[1] for x in state.splitlines()[1:10]}
            arm['frontier']=int(fields['frontier']);arm['committed_inputs']=arm['frontier']-window['low']+1
            arm['blocks']=int(fields['blocks']);arm['saved_fallback_inputs']=int(fields['fallbacks']);arm['saved_hits']=int(fields['hits'])
            arm['raw_hits']=(root/'hits.tsv').read_text().splitlines()[2:]
            arm['file_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir()}
          arm['whole_wall_seconds']=time.monotonic()-armstart
          arm['closure_seconds']=arm['whole_wall_seconds']-arm['setup_seconds']-arm.get('next_wall_seconds',0)
          arm['within_arm_cap']=time.monotonic()<=deadline
          if arm['status']=='COMPLETE':
            if arm.get('native_verify_rc')!=0 or arm['independent_record_audit']['state']!='DONE':raise RuntimeError('completed arm verification failure')
            arm['effective_inputs_per_second']=arm['committed_inputs']/arm['whole_wall_seconds']
          r['arms'].append(arm);r['elapsed_seconds']=time.monotonic()-started;receipt.write_text(json.dumps(r,indent=2)+'\n')
          print(tag,arm['status'],arm.get('committed_inputs'),round(arm['whole_wall_seconds'],3),flush=True)
        r.setdefault('window_wall_seconds',{})[window['id']]=time.monotonic()-ws
      r['comparisons']=[]
      for window in spec['windows']:
        aa=[a for a in r['arms'] if a['window']==window['id']]
        good=len(aa)==2 and all(a['status']=='COMPLETE' and a['within_arm_cap'] for a in aa) and aa[0]['raw_hits']==aa[1]['raw_hits']
        r['comparisons'].append({'window':window['id'],'status':'COMPARABLE' if good else 'INCONCLUSIVE','speedup16_over8':aa[0]['whole_wall_seconds']/aa[1]['whole_wall_seconds'] if good else None})
      # Archive closes within the one cumulative budget; no raw run is discarded.
      with tarfile.open(OUT/'calib.tgz','w:gz') as archive:
        for p in sorted(tmp.iterdir()):archive.add(p,arcname=p.name)
      r['whole_batch_seconds']=time.monotonic()-started;r['within_batch_cap']=r['whole_batch_seconds']<=300
      r['candidate_after']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/a249110.c',ROOT/'src/Makefile',EXE]}
      if r['candidate_after']!=r['candidate']:raise RuntimeError('Candidate changed during calibration')
      r['qualification']='COMPLETE_COMPARABLE' if all(c['status']=='COMPARABLE' for c in r['comparisons']) else 'OPEN_INCONCLUSIVE_NO_RETRY'
      receipt.write_text(json.dumps(r,indent=2)+'\n')
      print(r['qualification'],round(r['whole_batch_seconds'],3),flush=True)
if __name__=='__main__':main()
