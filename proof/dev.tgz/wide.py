#!/usr/bin/env python3
"""Bounded 5E10 capacity tests; no official interval search.

SymPy supplies factor candidates; recursive Lucas certificates independently
prove their primality. Python integer composition/isqrt compares with C/GMP.
The native inclusion helper is correlated implementation evidence, not an oracle.
"""
from pathlib import Path
import argparse, functools, json, math, signal, subprocess, tempfile
import sympy
from check import ROOT, LOG, require, command, build_helper, run

CAP=50000000000
MAX7=142962266571249025024
LIMIT=318665857834031151167461

@functools.lru_cache(None)
def certify(p):
    if p<2:return False
    if p<1000000:
        return all(p%q for q in range(2,math.isqrt(p)+1))
    factors={int(q):int(e) for q,e in sympy.factorint(p-1).items()}
    require(math.prod(q**e for q,e in factors.items())==p-1,'Lucas factor product')
    if not all(certify(q) for q in factors):return False
    for q in factors:
        if not any(pow(a,p-1,p)==1 and math.gcd(pow(a,(p-1)//q,p)-1,p)==1
                   for a in range(2,202)):
            return False
    return True

def factored(n):
    if n<2:return {}
    f={int(p):int(e) for p,e in sympy.factorint(n).items()}
    require(math.prod(p**e for p,e in f.items())==n,'independent factor product')
    require(all(certify(p) for p in f),'independent prime certificate')
    return f

def derivative(n):return sum(e*(n//p) for p,e in factored(n).items())

def chain(n):
    xs=[n]
    for _ in range(8):xs.append(derivative(xs[-1]))
    q=sum(x*x for x in xs);rt=math.isqrt(q)
    return xs+[rt,int(2<=n<=CAP and rt*rt==q)]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--exe',type=Path,default=ROOT/'src/a249110');ap.add_argument('--log',type=Path);a=ap.parse_args()
    try:
      with tempfile.TemporaryDirectory(prefix='a249110-wide-') as td:
        tmp=Path(td);helper=build_helper(tmp)
        primes=[int(sympy.nextprime(2**64)),int(sympy.prevprime(MAX7))]
        require(all(certify(p) for p in primes),'wide prime fixtures not certified')
        semis=[int(sympy.nextprime(2**32))*int(sympy.nextprime(2**32+100)),
               int(sympy.nextprime(9000000000))*int(sympy.nextprime(9000001000))]
        values=sorted(set([0,1,2,2**64-1,2**64,2**64+1,2**65,2**66,3*2**64,
                          MAX7-1,MAX7,*primes,*semis,3*primes[0],5*primes[0]]))
        expected={n:derivative(n) for n in values}
        actual=command([helper,'factorwide',*values],timeout=60).stdout.splitlines()
        require(len(actual)==len(values),'wide factor row count')
        for n,line in zip(values,actual):
            v=list(map(int,line.split()));require(v[:3]==[n,expected[n],1],f'wide derivative {n}')
        pp=command([helper,'primewide',*values,MAX7+1,LIMIT-1,LIMIT]).stdout.splitlines()
        require(len(pp)==len(values)+3,'wide prime row count')
        for n,line in zip(values+[MAX7+1,LIMIT-1,LIMIT],pp):
            f=factored(n) if n<LIMIT else {}
            want=-1 if n>=LIMIT else int(n>1 and f=={n:1})
            require(list(map(int,line.split()))==[n,want],f'wide prime {n}')
        v=list(map(int,command([helper,'factorwide',MAX7+1]).stdout.split()))
        require(v==[MAX7+1,0,0,0],'wide operand guard')
        require(command([helper,'stopwide']).stdout.strip()=='WIDE STOP INCOMPLETE','wide cancellation')
        for workers in (1,2,4,8,16):
            require(command([helper,'parallelwide',workers]).stdout.strip()=='WIDE PARALLEL PASS','wide per-worker scratch')
        forced=tmp/'forced';forced.mkdir();fh=build_helper(forced,extra=['-DA249110_FORCE_FALLBACK'])
        forced_values=[101*int(sympy.nextprime(2**64//101)),103*int(sympy.nextprime(2**64//103))]
        for n,line in zip(forced_values,command([fh,'factorwide',*forced_values]).stdout.splitlines()):
            require(list(map(int,line.split()))==[n,derivative(n),1,1],'wide exact fallback')
        signal_operand=1000000007*int(sympy.nextprime(2**64//1000000007))
        p=subprocess.Popen([str(fh),'signalwide',str(signal_operand)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        require(p.stdout.readline()=='WIDE_WORK_STARTED\n','wide signal start')
        p.send_signal(signal.SIGTERM);out,err=p.communicate(timeout=10)
        require(p.returncode==2 and out=='WIDE_SIGNAL_INCOMPLETE\n','wide signal classification')
        LOG.append({'test':'wide-signal','returncode':p.returncode,'stdout':out,'stderr':err,'input':signal_operand})
        originals=sorted(set([2**35,3*2**33,5*2**33,7*2**32,3**22,5**15,7**12,11**10,
                              *range(10000000000-4,10000000000+5),
                              *range(20000000000-4,20000000000+5),
                              *range(CAP-8,CAP+1)]))
        expected_chains=[chain(n) for n in originals]
        native=[list(map(int,row.split())) for row in command([helper,'chain',*originals],timeout=60).stdout.splitlines()]
        require(native==expected_chains,'upper-domain full-chain disagreement')
        for high in (10000000000,20000000000,CAP):
            lo=high-4 if high<CAP else high-8
            wanted=[x[:-1] for x in expected_chains if lo<=x[0]<=high and x[-1]]
            out=tmp/('end'+str(high));require(run(a.exe.resolve(),out,lo,high,workers=16)==wanted,'release upper boundary')
            command(['python3','-B',ROOT/'validation/verify.py',out,'--source-root',a.exe.resolve().parent.parent])
        domain=tmp/'domain';command([a.exe.resolve(),'init',domain,823544,CAP,76,16]);command([a.exe.resolve(),'status',domain]);command([a.exe.resolve(),'verify',domain],expect=2)
        command([a.exe.resolve(),'init',tmp/'bad',CAP+1,CAP+1,1,1],expect=1)
        LOG.append({'status':'PASS','wide_operands':values,'prime_certification':'recursive Lucas n-1 certificates, trial division below 1E6; SymPy factor candidates product checked',
                    'wide_factor_expected':expected,'forced_fallback_operands':forced_values,'upper_original_inputs':originals,'full_chains':expected_chains,
                    'widest_actual_x7_bits':max(x[7].bit_length() for x in expected_chains),'synthetic_wide_operand_bits':max(n.bit_length() for n in values),
                    'production_boundary_inputs':19,'large_range_initialization_only':True,'official_campaign':False})
    finally:
      if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
    print('WIDE CAPACITY PASS')

if __name__=='__main__':main()
