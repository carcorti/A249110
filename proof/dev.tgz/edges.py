#!/usr/bin/env python3
"""Extra current-build boundary checks: max states, baseline snapshot, RSS,
independent verifier refusal and flush failures; no new range enumeration."""
from pathlib import Path
import argparse,json,shutil,tempfile,os,subprocess
from check import ROOT,LOG,require,command,run,hits

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--log',type=Path);a=ap.parse_args();exe=ROOT/'src/a249110'
 try:
  with tempfile.TemporaryDirectory(prefix='a249110-edge-') as td:
    tmp=Path(td);d=tmp/'s256';command([exe,'init',d,2,67108865,256,16]);command([exe,'status',d]);command([exe,'verify',d],expect=2)
    require(len(list(d.iterdir()))==259 and (d/'s255.tsv').exists(),'maximum initialization artifact count')
    copied=tmp/'copy';(copied/'src').mkdir(parents=True);(copied/'data').mkdir()
    for p in ['a249110.c','Makefile','a249110']:shutil.copy2(ROOT/'src'/p,copied/'src'/p)
    shutil.copyfile(ROOT/'data/b249110.txt',copied/'data/b249110.txt')
    binary=copied/'src/a249110';d=tmp/'snap';command([binary,'init',d,2,4096,1,2]);(copied/'data/b249110.txt').unlink();command([binary,'next',d]);command([binary,'verify',d])
    require([h[0] for h in hits(d)]==[4,27,3125],'live b-file dependency survived init')
    raw=(ROOT/'data/b249110.txt').read_bytes()
    for tag,b in [('empty',b''),('short',raw[:-1]),('extra',raw+b'\n'),('nul',raw.replace(b'1 4',b'1\0 4')),('cr',raw.replace(b'\n',b'\r\n')),('index',raw.replace(b'2 27',b'3 27')),('value',raw.replace(b'2 27',b'2 28')),('leading',raw.replace(b'1 4',b'01 4'))]:
        (copied/'data/b249110.txt').write_bytes(b);command([binary,'init',tmp/tag,2,4096,1,2],expect=1)
    command(['python3','-B',ROOT/'validation/verify.py',d,'--source-root',copied])
    p=d/'s000.tsv';p.write_bytes(p.read_bytes().replace(b'\t12\n',b'\t13\n'));command(['python3','-B',ROOT/'validation/verify.py',d],expect=1)
    lib=tmp/'fault.so';command(['gcc','-shared','-fPIC',ROOT/'validation/io_faults.c','-ldl','-o',lib])
    for at in range(1,9):
        d=tmp/f'fl{at}';command([exe,'init',d,2,4096,1,2]);env={**os.environ,'LD_PRELOAD':str(lib),'A249110_FAULT':'fflush','A249110_AT':str(at)}
        command([exe,'next',d],expect=(0,1),env=env);command([exe,'next',d]);command([exe,'verify',d]);require([h[0] for h in hits(d)]==[4,27,3125],'flush failure lost data')
    d=tmp/'rss';command([exe,'init',d,2,4096,1,16]);r=command(['/usr/bin/time','-v',exe,'next',d]);command(['python3','-B',ROOT/'validation/verify.py',d,'--source-root',ROOT])
    command(['valgrind','--leak-check=full','--show-leak-kinds=definite,indirect','--errors-for-leak-kinds=definite,indirect','--error-exitcode=99',exe,'verify',d])
    LOG.append({'status':'PASS','scope':'supplemental boundaries, no calibration repetition'})
 finally:
  if a.log:a.log.write_text(json.dumps(LOG,indent=2)+'\n')
 print('EDGE PASS')
if __name__=='__main__':main()
