#include <omp.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char **argv) {
    if(argc!=2) return 1;
    if(!strcmp(argv[1],"startup")) return 0;
    int v[1024]={0},sum=0;
    _Atomic int count=0;
    if(!strcmp(argv[1],"sync")) {
#pragma omp parallel num_threads(4) reduction(+:sum)
        {
#pragma omp for schedule(dynamic,64)
            for(int i=0;i<1024;++i) { v[i]=i; atomic_fetch_add_explicit(&count,1,memory_order_relaxed); }
#pragma omp for
            for(int i=0;i<1024;++i) sum+=v[i];
        }
        return sum==523776&&atomic_load(&count)==1024?0:1;
    }
    if(!strcmp(argv[1],"race")) {
#pragma omp parallel for num_threads(4)
        for(int i=0;i<1024;++i) v[0]++;
        printf("%d\n",v[0]); return 0;
    }
    return 1;
}
